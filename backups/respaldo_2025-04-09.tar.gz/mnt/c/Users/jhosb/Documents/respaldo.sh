#!/bin/bash
# Configuración
origen="/mnt/c/Users/jhosb/Documents"
destino="/mnt/c/Users/jhosb/Documents/backups"
nombre_backup="respaldo_$(date +%Y-%m-%d).tar.gz"
REPO_DIR="/mnt/c/Users/jhosb/Documents/jhosberSyH/PracticasSo.git"

echo "Iniciando respaldo..."

# Crear directorio de backups si no existe
if [ ! -d "$destino" ]; then
    mkdir -p "$destino"
    echo "Se creó el directorio $destino"
fi

# Crear el archivo comprimido
echo "Creando respaldo..."
tar -czf "$destino/$nombre_backup" "$origen"

# Verificar si el respaldo se creó
if [ -f "$destino/$nombre_backup" ]; then
    echo "Respaldo creado correctamente en $destino/$nombre_backup"
else
    echo "Error al crear el respaldo!"
    exit 1
fi
echo "Proceso de respaldo completado!"
# 3. Copiar respaldo al repositorio
cp "$DESTINO/$NOMBRE_BACKUP" "$REPO_DIR/backups/"
# 4. Actualizar repositorio Git
cd "$REPO_DIR"
git add backups/"$NOMBRE_BACKUP"
git commit -m "Respaldo automático: $(date +%Y-%m-%d)"
git push origin main
echo "Proceso completado con éxito!"

